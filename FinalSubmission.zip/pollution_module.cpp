#include "pollution_module.h"

void PollutionModule::spreadPollution() {
    // Pollution logic
}
