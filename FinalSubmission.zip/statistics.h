#pragma once
class Statistics {
public:
    void logMetrics();
};
