#pragma once
class Controller {
public:
    void runSimulation();
};
