Final Project Submission
------------------------

This folder contains all source and header files required to compile and run the city simulation project.
Do not include executables or configuration files.

Files:
- main.cpp
- controller.{cpp,h}
- map_loader.{cpp,h}
- zoning_engine.{cpp,h}
- pollution_module.{cpp,h}
- statistics.{cpp,h}
