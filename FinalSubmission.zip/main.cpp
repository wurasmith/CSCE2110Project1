#include "controller.h"

int main() {
    Controller controller;
    controller.runSimulation();
    return 0;
}
