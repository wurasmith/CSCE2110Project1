#pragma once
class MapLoader {
public:
    void loadMap(const char* filename);
};
