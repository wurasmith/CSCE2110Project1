#pragma once
class ZoningEngine {
public:
    void updateZones();
};
