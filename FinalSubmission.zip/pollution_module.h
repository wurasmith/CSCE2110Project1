#pragma once
class PollutionModule {
public:
    void spreadPollution();
};
