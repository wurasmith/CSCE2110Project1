# Region Analysis

## Purpose
Provides statistical data on total populations and pollution for the full region or a user-defined subregion.

## Data Storage and Maintenance
- Coordinates and region grid are used.
- Validates bounds on input.

## Functionality
- analyzeRegion(x1, y1, x2, y2): Computes regional totals.
```cpp
if (x1 < 0 || x2 >= cols || y1 < 0 || y2 >= rows) {
    // Prompt user again
}
```
