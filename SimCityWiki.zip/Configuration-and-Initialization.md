# Configuration and Initialization

## Purpose
This component reads the configuration file, initializes simulation parameters, and loads the region layout into a grid structure.

## Data Storage and Maintenance
- `Config` struct stores:
  - Region layout filename
  - Maximum time steps
  - Refresh rate
- Region layout loaded from a CSV file into a 2D vector of `Cell` objects.

## Functionality
- readConfig(string filename): Reads and stores configuration values.
- loadRegion(string layoutFile): Parses CSV and fills the region grid.
