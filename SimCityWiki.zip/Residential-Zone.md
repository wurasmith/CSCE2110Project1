# Residential Zone

## Purpose
Simulates residential growth and generates workers for commercial and industrial zones.

## Data Storage and Maintenance
- Uses shared 2D region grid.
- Tracks population, power status in each cell.

## Functionality
- growResidential(): Applies growth rules based on population and adjacency.
```cpp
if (cell.population == 0 && isPowered(cell)) {
    cell.population++;
    workers++;
}
```
