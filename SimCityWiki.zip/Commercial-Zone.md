# Commercial Zone

## Purpose
Simulates commercial growth that consumes workers and goods.

## Data Storage and Maintenance
- Pulls from global workers and goods counters.
- Tracks population and power status in each cell.

## Functionality
- growCommercial(): Applies growth rules and resource availability.
```cpp
if (isPowered(cell) && workers > 0 && goods > 0) {
    cell.population++;
    workers--;
    goods--;
}
```
