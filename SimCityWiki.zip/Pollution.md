# Pollution

## Purpose
Manages pollution generated from industrial zones and spreads it to neighboring cells.

## Data Storage and Maintenance
- Pollution level per Cell.
- Spread diminishes by 1 per adjacent level.

## Functionality
- spreadPollution(int x, int y, int amount): Distributes pollution.
```cpp
region[y][x].pollution += amount;
for each neighbor:
    region[ny][nx].pollution += (amount - 1);
```
