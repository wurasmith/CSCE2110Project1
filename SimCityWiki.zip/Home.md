# High-Level System Overview

## Overview
This project simulates the growth and interaction of a simplified city layout with residential, commercial, industrial, and utility zones. Over time, based on predefined rules and user inputs, the system evolves and outputs the state of the region at regular intervals.

## Major Functionality Components
- Configuration & Initialization
- Residential Zone
- Commercial Zone
- Industrial Zone
- Pollution
- Region Analysis

## Core Data Structures

### Cell Representation
```cpp
struct Cell {
    char zoneType; // 'R', 'C', 'I', '-', 'T', '#', 'P'
    int population = 0;
    int pollution = 0;
    bool powered = false;
};
```

### Configuration
```cpp
struct Config {
    std::string layoutFile;
    int maxTimeSteps;
    int refreshRate;
};
```

## System Diagram
![System Diagram](Insert_Diagram_Link_Here)

## Navigation
- [Configuration & Initialization](Configuration-and-Initialization)
- [Residential Zone](Residential-Zone)
- [Commercial Zone](Commercial-Zone)
- [Industrial Zone](Industrial-Zone)
- [Pollution](Pollution)
- [Region Analysis](Region-Analysis)
