# Industrial Zone

## Purpose
Produces goods, consumes workers, and emits pollution.

## Data Storage and Maintenance
- Tracks goods produced and pollution emitted.
- Pollution is stored per cell.

## Functionality
- growIndustrial(): Handles growth and pollution spread.
```cpp
if (workers >= 2 && isPowered(cell)) {
    cell.population++;
    workers -= 2;
    goods++;
    spreadPollution(cell.x, cell.y, cell.population);
}
```
